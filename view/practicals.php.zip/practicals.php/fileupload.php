<?php
// Requiring database_connecting_test.php file
require ('database_connection_test.php');
if(isset($_POST['Submit'])){
   
    //Let the root server file = a variable
    echo "<h4>The file chosen is:  </h4>";
$target_dir = "user_images/";
    // file path

$target_file = $target_dir.basename($_FILES["myfile"]["name"]);

$image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

//checking for fake images
$check = getimagesize($_FILES["myfile"]["tmp_name"]);
    if($check !== False){
echo "File is an image - ".$check["mime"].".<br>";
}else{
echo "File is not an image.";
}


    //checking if file already exists
if(file_exists($target_file)){
        echo " file already exists.";
         
   }

   // Check file size
   if ($_FILES["myfile"]["size"] > 500000) {
         echo "File is too large.";
         
   }

// Allowing certain file formats jpg,jpeg,png
if($image_file_type != "jpg" && $image_file_type != "png" && $image_file_type != "jpeg"
&& $image_file_type != "gif" ) {
  echo "Only JPG, JPEG, PNG & GIF files are allowed.";
}

if ($uploadOk === 0) {
echo "Sorry, your file was not uploaded.";
}
else{
  $uploadImage = move_uploaded_file($_FILES["myfile"]["tmp_name"],$target_file);
  if($uploadImage){
    // Inserting into the Database
  $sql="INSERT INTO `practical_upload_table`(`User_image`) VALUES ('$target_file')";
  $resultINSERT=$conn->query($sql);
  if($resultINSERT === True){
    echo "File uploaded successfully"."<br>";
  } else{
    echo "File upload  Failed ".$conn->error;
  }
}
}


}

?>