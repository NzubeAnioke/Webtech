<?php
require ('database_connection_test.php');

if (isset($_POST['Submit'])){
  $message=$_POST['Search'];

  //check for regular expression
  $pattern = "/[0-9]";
if(preg_match($pattern, $message) === True){
  
  // Inserting into the Database
  $sql="INSERT INTO `practical_lab_table`(`Search_term`) VALUES ('$message')";
  
  $resultINSERT=$conn->query($sql);
  if($resultINSERT === True){
    echo "Record inserted successfully"."<br>";
  } else{
    echo "Insertion Failed ".$conn->error;
  }
}
else{
    echo " Only Numbers allowed";
}
}

?>