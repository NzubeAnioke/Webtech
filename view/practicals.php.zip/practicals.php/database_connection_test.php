<?php
	require "database_credentials.php";

			$dbconnection = new mysqli(servername, username,password, database);

			if ($dbconnection->connect_error) {
					die("CONNECTION FAILED: ". mysqli_connect_error());

					echo "CONNECTION FAILED";
			}

			else{
				echo "CONNECTION SUCCESSFUL";

			}
			$dbconnection->close();





?>