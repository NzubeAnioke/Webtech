<?php
		
		define("servername","localhost");
		define("username","root");
		define("password","");
		define("database","lab_post");
		?>